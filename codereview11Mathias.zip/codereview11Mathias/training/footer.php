<div class="col-sm-4 col-sm-offset-4">
    <p class="text-center">travelblog &copy; 2017</p>
  </div>
</div>
</body>
</html>