<?php get_header(); ?>


	
</div>
<div class="container main-container">

	<div class="row">

		<div class="col-sm-8 blog-main">

			<?php 
			if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  	
				


<h1><?php the_title(); // blog post title ?></h1>


<?php the_content(); // blog post content ?>





<?php the_date(); // blog post date ?>


<?php the_time(); // blog post time ?>


<?php the_author(); // blog post author ?>



  <?php
			endwhile; endif; 
			?>

		</div> <!-- /.blog-main -->

<?php


       if(is_active_sidebar('sidebar')):

       dynamic_sidebar('sidebar');


       endif;

       

?>

	</div> <!-- /.row -->

</div>
<?php get_footer(); ?>
