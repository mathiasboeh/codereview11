<!DOCTYPE html>
<html>
<head>
	  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="profile" href="<?php echo esc_url( 'gmpg.org/xfn/11' ); ?>">
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

  <link rel="stylesheet" href="<?php echo get_template_directory_uri()."/style.css"?>">

  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<title></title>
</head>
<body>
	<?php
	 // $curUrl = get_template_directory_uri() . "/img/New_York_Midtown_Skyline_at_night_-_Jan_2006_edit1.jpg";
	 // echo "<header style=\" background-size: cover; background-image:url(".$curUrl.")\"id=\"masthead\" class=\"site-header\">";

	?>

	<div class="blog-masthead">

     <div class="container">

       <nav class="blog-nav">

         <?php

           wp_nav_menu( array(

               'menu'              => 'primary',

               'theme_location'    => 'primary',

               'depth'             => 2,

               'container'         => 'div',

               'container_class'   => 'collapse navbar-collapse',

               'container_id'      => 'bs-example-navbar-collapse-1',

               'menu_class'        => 'nav navbar-nav',

               'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',

               'walker'            => new WP_Bootstrap_Navwalker())

           );

       ?>

       </nav>

     </div>

   </div>

